Проектная работа 3 
"Путешествия по России"
ссылка проекта на GitHub: https://github.com/lilitlili/russian-travel.git
